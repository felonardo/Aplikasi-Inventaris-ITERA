/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.model;

import com.controller.controller_pinjam;
import com.koneksi.koneksi;
import com.view.Fr_Inventaris;
import com.view.Fr_Lokasi;
import com.view.Fr_Pegawai;
import com.view.Fr_Pinjam;
import com.view.Fr_Vendor;
import com.view.Popup_TambahInventaris;
import com.view.Popup_TambahLokasi;
import com.view.Popup_TambahPegawai;
import com.view.Popup_TambahPinjam;
import com.view.Popup_TambahVendor;
import com.view.UI_Login;
import java.awt.Component;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.util.HashMap;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;


/**
 *
 * @author USER
 */
public class model_pinjam extends model implements controller_pinjam{

    Connection Connect = koneksi.getKoneksi();
    
      HashMap<Integer, Object> mapPinjam=new HashMap<>();
//      HashMap<Integer, Object> mapBarang = new HashMap<>();



    
    @Override
    public void tambah(Popup_TambahPinjam Pop, Fr_Pinjam Fr, UI_Login log) {
        String nama_peminjam=Pop.txtNama.getText().trim();
        int jum=Integer.valueOf(Pop.txtJumlah.getText().trim());
        String uname = log.txtUsername.getText().trim();
        int jumA = 0;
        
        int id_barang=Pop.CmbBarang.getSelectedIndex()+1;
        Object barang = Pop.CmbBarang.getSelectedItem();
        System.out.println(barang);
        //harus ditambahkan cara mencegah data kosong dan sejenisnya tanya asprak
        String cekJum = "select jumlah_barang from barang where id_barang = (select id_barang from barang where nama_barang = '"+barang+"');";
        System.out.println(cekJum);
        
        try{
            Statement stat = Connect.createStatement();
            ResultSet hasil = stat.executeQuery(cekJum);
            
            while(hasil.next()){
                jumA = hasil.getInt("jumlah_barang");
            }
        }
        catch (SQLException e){
            JOptionPane.showMessageDialog(null,"Data Gagal ditambahkan "+e);;
        }
        
        if(jum>jumA){
            JOptionPane.showMessageDialog(Pop, "Barang yang dipinjam terlalu banyak");
        }else if(jum<0){            
            JOptionPane.showMessageDialog(Pop, "Barang yang dipinjam tidak boleh bernilai negatif");
        }else{            
            String insert="INSERT INTO pinjam (peminjam,id_barang,jumlah_barang,tanggal_pinjam, petugas, flag) VALUES ('"
                +nama_peminjam+"',"
                +"(select id_barang from barang where nama_barang = '"+barang+"'),"
                +jum+", CURRENT_TIMESTAMP,'"+
                uname+"',"
                +1+");";
            String update = "update barang set "
                  +"jumlah_barang = '"+(jumA-jum)+"' where nama_barang = '"+barang+"';";
            System.out.println(update);
            try{
                Statement stat = Connect.createStatement();
                stat.executeUpdate(insert);
                stat.executeUpdate(update);
                JOptionPane.showMessageDialog(null,"Data Berhasil ditambahkan ");
                showtables(Fr);
    
            }
            catch (SQLException e){
                JOptionPane.showMessageDialog(null,"Data Gagal ditambahkan "+e);;
            }
        }        
//        System.out.println(insert);
        showtables(Fr);
    }

    @Override
    public void showtables(Fr_Pinjam Fr) {
            
        int i=0;   
            Object [] rows={"Peminjam","Nama Barang","Jumlah","Waktu Pinjam","Waktu Kembali","Petugas"};
            DefaultTableModel dtm=new DefaultTableModel(null,rows){
               public boolean isCellEditable(int rowIndex, int colIndex) {
                return false;
               }
            };
          
           
            Fr.TbBarang.setModel(dtm);
            Fr.TbBarang.setBorder(null);
            Fr.TbBarang.removeAll();
//            jScrollPane1.setVisible(true);
//            jScrollPane1.setViewportView(Fr.TbBarang);
             String query="select id_peminjaman, peminjam, nama_barang, pinjam.jumlah_barang, tanggal_pinjam, tanggal_kembali, nama_petugas from barang, pinjam, petugas where petugas.username =pinjam.petugas &&barang.id_barang=pinjam.id_barang && pinjam.flag = 1 order by tanggal_kembali asc;";
        
        
        try{
            Statement stat = Connect.createStatement();
            ResultSet hasil = stat.executeQuery(query);
            
            while(hasil.next()){
                Object[] obj=new Object[6];
                obj[0]=hasil.getString("peminjam");
                obj[1]=hasil.getString("nama_barang");
                obj[2]=hasil.getString("jumlah_barang");
                obj[3]=hasil.getString("tanggal_pinjam");
                obj[4]=hasil.getString("tanggal_kembali");
                obj[5]=hasil.getString("nama_petugas");
                int idpinjam=hasil.getInt("id_peminjaman");
                        
                mapPinjam.put(i,idpinjam);
                i++;
                dtm.addRow(obj);
                        
             }
        }
        catch (SQLException e){
            System.out.println("Gagal eksekusi query select");
        }
    }
    
    @Override
    public void showComboTambah(Popup_TambahPinjam combo){
        
        try {
        Object[] objLokasi = new Object[5];    
        String queryVendor = "select nama_vendor from vendor;";
        String queryBarang = "select nama_barang from barang where jumlah_barang>0 && permanen = 0;";
        String queryLokasi = "select nama_lokasi from lokasi;";
        String queryRuang = "select nama_ruang from ruang";

        
        Statement stat = Connect.createStatement();  
        
        ResultSet hasilVendor = stat.executeQuery(queryVendor);
        
        //show combo Vendor
        while(hasilVendor.next()){
            Object[] obj = new Object[5];
            
            obj[0] = hasilVendor.getString("nama_vendor");
            
//            combo.CmbVendor.addItem(obj[0]);      
        }
        hasilVendor.close();
        
        //show combo Jenis
        ResultSet hasilBarang = stat.executeQuery(queryBarang);  
        while(hasilBarang.next()){
            Object[] obj = new Object[5];
            
            obj[0] = hasilBarang.getString("nama_barang");
            
            combo.CmbBarang.addItem(obj[0]);      
        }
        hasilBarang.close();
        
        //show combo Lokasi  
        ResultSet hasilLokasi = stat.executeQuery(queryLokasi);  
        while(hasilLokasi.next()){
//            Object[] obj = new Object[5];
            
            objLokasi[0] = hasilLokasi.getString("nama_lokasi");
            
//            combo.CmbLokasi.addItem(objLokasi[0]);      
        }
            hasilLokasi.close(); 
        
        //show combo Ruang
        ResultSet hasilRuang = stat.executeQuery(queryRuang);  
        while(hasilRuang.next()){
            Object[] obj = new Object[5];
            
            obj[0] = hasilRuang.getString("nama_ruang");
            
//            combo.CmbRuang.addItem(obj[0]);      
        }
            hasilRuang.close();
            stat.close();
        
        //show combo Keterangan
            Object[] Ket =new Object[2];
            Ket[0]="Permanen";
            Ket[1]="Tidak Permanen";
//            combo.CmbKet.addItem(Ket[0]);
//            combo.CmbKet.addItem(Ket[1]);
        
        //show combo Kondisi
            Object[] Kondisi = new Object[3];
            Kondisi[0]="Baru";
            Kondisi[1]="Rusak";
            Kondisi[2]="Service";
//            combo.CmbKondisi.addItem(Kondisi[0]);
//            combo.CmbKondisi.addItem(Kondisi[1]);
//            combo.CmbKondisi.addItem(Kondisi[2]);
            
         
        } catch (Exception e) {
            System.out.println(e.getMessage());
            
        }
    }


//    @Override
//    public void showAtributEdit(Popup_EditPinjam Pop,int row) {
//            
//            String query=" Select jumlah_barang,nama_barang,nama_vendor from barang,vendor where id_barang="+row+" && barang.id_vendor=vendor.id_vendor;";
//        
//        try{
//        
//            Statement stat = Connect.createStatement();
//            ResultSet hasil = stat.executeQuery(query);
//            
//                while(hasil.next()){
//                    int jum=hasil.getInt("jumlah_barang");
//                    String nama=hasil.getString("nama_barang");
//                    String vendor=hasil.getString("nama_vendor");
//                    
//                    
//                    Pop.txtJum.setText(String.valueOf(jum));
//                    Pop.LblN.setText("harus <="+jum);
//                    Pop.lblNama.setText(nama);
//                    Pop.lblVendor.setText(vendor);
//                }       
//        }
//        
//        catch (SQLException e){
//            
//        }
//    
//        
//    }

//    @Override
//    public void showComboEdit(Popup_EditPinjam Pop) {
//        
//        String queryLokasi="select nama_lokasi from lokasi";
//        String queryRuang="select nama_ruang from ruang";
//        
//        
//        try{
//            Statement stat=Connect.createStatement();
//            ResultSet hasilLokasi=stat.executeQuery(queryLokasi);
//            
//            while(hasilLokasi.next()){
//                Object[] objLokasi=new Object[1];
//                
//                objLokasi[0]=hasilLokasi.getString("nama_lokasi");
//                
//                Pop.CmbLokasi.addItem(objLokasi[0]);
//            }
//            hasilLokasi.close();
//            
//            ResultSet hasilRuang=stat.executeQuery(queryRuang);
//            
//            while(hasilRuang.next()){
//                Object[] objRuang=new Object[1];
//                
//                objRuang[0]=hasilRuang.getString("nama_ruang");
//                
//                Pop.CmbRuang.addItem(objRuang[0]);
//            }
//            hasilRuang.close();
//            
//            Object[] Kondisi = new Object[3];
//            Kondisi[0]="Baru";
//            Kondisi[1]="Rusak";
//            Kondisi[2]="Service";
//            Pop.CmbKondisi.addItem(Kondisi[0]);
//            Pop.CmbKondisi.addItem(Kondisi[1]);
//            Pop.CmbKondisi.addItem(Kondisi[2]);
//            
//        }
//        catch (SQLException e){
//            JOptionPane.showMessageDialog(Pop, "Gagal menampilkan Combo box"+e);
//                    
//        }
//    }

    @Override
    public void kembali(Fr_Pinjam Fr, int row) {
        int idBarang =0;
        int jumlahBarang = 0;
        int jumlahKembali = 0;
        String cekDate = null;
        String sel = "select pinjam.id_barang, pinjam.jumlah_barang, barang.jumlah_barang, tanggal_kembali from pinjam, barang where id_peminjaman="+mapPinjam.get(row)+"&& barang.id_barang = pinjam.id_barang;";
        String update="update pinjam set "
            +"tanggal_kembali = CURRENT_TIME() where id_peminjaman = "+mapPinjam.get(row)+";";
  ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////   
        System.out.println(update);
        System.out.println("id/row:"+row);
        
        try{
            Statement stat = Connect.createStatement();
            ResultSet hasil = stat.executeQuery(sel);
            
            while(hasil.next()){
                idBarang = hasil.getInt(1);
                jumlahKembali = hasil.getInt(2);
                jumlahBarang = hasil.getInt(3);
                cekDate = hasil.getString("tanggal_kembali");
            }
            System.out.println(jumlahKembali+jumlahBarang);
            System.out.println(idBarang);
            System.out.println("ini tanggal"+cekDate);
            if (cekDate ==null){
            String update2 = "update barang set "
                    +"jumlah_barang = "+(jumlahBarang+jumlahKembali)+" where id_barang ="+idBarang+";";
            stat.executeUpdate(update);
            stat.executeUpdate(update2);
            JOptionPane.showMessageDialog(Fr, "Barang berhasil kembali");
            showtables(Fr);
            } else {
                JOptionPane.showMessageDialog(Fr, "Data tidak bisa diedit");
            }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////            
        }
        catch (SQLException e){
            JOptionPane.showMessageDialog(Fr, "Gagal mengembalikan barang "+e);
        }
        showtables(Fr);
    }       

    @Override
    public void tambah(Popup_TambahVendor Pop, Fr_Vendor Fr) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void tambah(Popup_TambahInventaris Pop, Fr_Inventaris Fr) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void tambah(Popup_TambahLokasi Pop, Fr_Lokasi Fr) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void tambah(Popup_TambahPegawai Pop, Fr_Pegawai Fr) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
