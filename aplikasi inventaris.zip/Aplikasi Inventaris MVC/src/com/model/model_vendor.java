/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.model;
import com.controller.controller_vendor;
import com.koneksi.koneksi;
import com.view.Fr_Inventaris;
import com.view.Fr_Lokasi;
import com.view.Fr_Pegawai;
import com.view.Fr_Pinjam;
import com.view.Fr_Vendor;
import com.view.Popup_EditVendor;
import com.view.Popup_TambahInventaris;
import com.view.Popup_TambahLokasi;
import com.view.Popup_TambahPegawai;
import com.view.Popup_TambahPinjam;
import com.view.Popup_TambahVendor;
import com.view.UI_Login;
import java.awt.Component;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.util.HashMap;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;


/**
 *
 * @author USER
 */
public class model_vendor extends model implements controller_vendor{
    Connection Connect = koneksi.getKoneksi();
    
    HashMap<Integer, Integer> mapVendor=new HashMap<>();

    
    @Override
    public void tambah(Popup_TambahVendor Pop, Fr_Vendor Fr) {
        String vendor=Pop.txtVendor.getText().trim();
        String alamat=Pop.txtAlamat.getText().trim();
        String kontak=Pop.txtKontak.getText().trim();
        
        //harus ditambahkan cara mencegah data kosong dan sejenisnya tanya asprak
        
        String insert="INSERT INTO vendor (nama_vendor,alamat,no_hp, flag) VALUES ('"
                +vendor+"','"
                +alamat+"','"
                +kontak+"',"
                +1+");";
         try{
            PreparedStatement stat = (PreparedStatement) Connect.prepareStatement(insert);
            stat.executeUpdate();
            JOptionPane.showMessageDialog(null,"Data Berhasil ditambahkan ");
            showtables(Fr);
    
        }
        catch (SQLException e){
            JOptionPane.showMessageDialog(null,"Data Gagal ditambahkan "+e);;
        }
        
        System.out.println(insert);
        showtables(Fr);
    }

    @Override
    public void showtables(Fr_Vendor Fr) {
            
        int i=0;

            Object [] rows={"Vendor","Alamat","Kontak"};
            DefaultTableModel dtm=new DefaultTableModel(null,rows){
               public boolean isCellEditable(int rowIndex, int colIndex) {
                return false;
               }
            };
          
           
            Fr.TbBarang.setModel(dtm);
            Fr.TbBarang.setBorder(null);
            Fr.TbBarang.removeAll();
            String query="select * from vendor where flag = 1;";
        
        
        try{
            Statement stat = Connect.createStatement();
            ResultSet hasil = stat.executeQuery(query);
            
            while(hasil.next()){
                Object[] obj=new Object[7];
                obj[0]=hasil.getString("nama_vendor");
                obj[1]=hasil.getString("alamat");
                obj[2]=hasil.getString("no_hp");
                int id=hasil.getInt("id_vendor");
                
               mapVendor.put(i,id);
                i++;

                        
                dtm.addRow(obj);
             }
        }
        catch (SQLException e){
            System.out.println("Gagal eksekusi query select");
        }
    }

    @Override
    public void showAtributEdit(Popup_EditVendor Pop,int row) {
        
            
            String query=" Select * from vendor where id_vendor="+mapVendor.get(row)+";";
        
        try{
        
            Statement stat = Connect.createStatement();
            ResultSet hasil = stat.executeQuery(query);
            
                while(hasil.next()){
                    String vendorE=hasil.getString("nama_vendor");
                    String alamatE=hasil.getString("alamat");
                    String kontakE=hasil.getString("no_hp");
                    
                    Pop.txtVendor.setText(String.valueOf(vendorE));
                    Pop.txtAlamat.setText(String.valueOf(alamatE));
                    Pop.txtKontak.setText(String.valueOf(kontakE));
                }       
        }
        
        catch (SQLException e){
            
        }
    
        
    }
    
    @Override
    public void delete (Fr_Vendor Fr,int id) {
        String update="update vendor set flag=0 where id_vendor='"+mapVendor.get(id)+"';";
//        System.out.println(update);
//        System.out.println("id:"+id);
        
          try{
            PreparedStatement stat=(PreparedStatement) Connect.prepareStatement(update);
            stat.executeUpdate();
            System.out.println("Delete Berhasil");
            showtables(Fr);
        }
        catch (SQLException e){
            System.out.println("Gagal eksekusi query Delete"+e);
        }
          
//          String vendorE = Pop.txtVendor.getText().trim();
//          String alamatE = Pop.txtAlamat.getText().trim();
//          String kontakE = Pop.txtKontak.getText().trim();
//          String querye="update vendor set "
//                  +"nama_vendor = '"+vendorE+"', "
//                  +"alamat = '"+alamatE+"', "
//                  +"no_hp = '"+kontakE+"' where id_vendor = "+mapVendor.get(row)+";";
//  ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////          
//        try{
//            
//            Statement stat = Connect.createStatement();
//            stat.executeUpdate(querye);
//            JOptionPane.showMessageDialog(Pop, "Data berhasil diubah");
//            showtables(Fr);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////            
//        }
//        catch (SQLException e){
//            JOptionPane.showMessageDialog(Pop, "Gagal merubah data"+e);
//        }
    showtables(Fr);
    }

    @Override
    public void tambah(Popup_TambahInventaris Pop, Fr_Inventaris Fr) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void tambah(Popup_TambahPinjam Pop, Fr_Pinjam Fr, UI_Login log) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void tambah(Popup_TambahLokasi Pop, Fr_Lokasi Fr) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void tambah(Popup_TambahPegawai Pop, Fr_Pegawai Fr) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
