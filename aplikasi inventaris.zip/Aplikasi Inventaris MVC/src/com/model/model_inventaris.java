/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.model;

import com.controller.controller_inventaris;
import com.koneksi.koneksi;
import com.view.Fr_Inventaris;
import com.view.Fr_Lokasi;
import com.view.Fr_Pegawai;
import com.view.Fr_Pinjam;
import com.view.Fr_Vendor;
import com.view.Popup_Edit;
import com.view.Popup_TambahInventaris;
import com.view.Popup_TambahLokasi;
import com.view.Popup_TambahPegawai;
import com.view.Popup_TambahPinjam;
import com.view.Popup_TambahVendor;
import com.view.UI_Login;
import java.awt.Component;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import org.omg.PortableInterceptor.SYSTEM_EXCEPTION;


/**
 *
 * @author USER
 */
public class model_inventaris extends model implements controller_inventaris {

    Connection Connect = koneksi.getKoneksi();
    
    HashMap<Integer, Integer> mapInventaris=new HashMap<>();
    
    HashMap<Integer, Integer> map =new HashMap<>();

    
    
    @Override
    public void tambah(Popup_TambahInventaris Pop, Fr_Inventaris Fr) {
        String nama_barang=Pop.txtNamaB.getText().trim();
        int jum=Integer.valueOf(Pop.txtJumlah.getText().trim());
        
        System.out.println(nama_barang);
        System.out.println(jum);
        
        //harus ditambahkan cara mencegah data kosong dan sejenisnya tanya asprak
               
//        int id_lokasi=Pop.CmbLokasi.getSelectedIndex()+1;
        int id_ruang=Pop.CmbRuang.getSelectedIndex()+1;
        Object ruang=Pop.CmbRuang.getSelectedItem();
        Object lokasi=Pop.CmbLokasi.getSelectedItem();
        int id_jenis=Pop.CmbJenis.getSelectedIndex()+1;
        int id_vendor=Pop.CmbVendor.getSelectedIndex()+1;
        String kondisi=String.valueOf(Pop.CmbKondisi.getSelectedItem());
        int permanen=Pop.CmbKet.getSelectedIndex();
        
        
        System.out.println("idjenis:"+id_ruang);
        
        String insert="INSERT INTO barang (nama_barang,id_ruang,jumlah_barang,id_jenis_barang,kondisi,permanen,id_vendor,flag) VALUES ('"
                +nama_barang+"',"
//                +id_lokasi+","
                +"(select id_ruang from ruang where nama_ruang = '"+ruang+"' AND id_gedung = (select id_lokasi from lokasi where nama_lokasi = '"+lokasi+"')),"
                +jum+","
                +id_jenis+",'"
                +kondisi+"',"
                +permanen+","
                +id_vendor+","
                +1+");";
        System.out.println(insert);
         try{
            PreparedStatement stat = (PreparedStatement) Connect.prepareStatement(insert);
            stat.executeUpdate();
            JOptionPane.showMessageDialog(null,"Data Berhasil ditambahkan ");
            Fr.TbBarang.removeAll();
            showtables(Fr);
    
        }
        catch (SQLException e){
            JOptionPane.showMessageDialog(null,"Data Gagal ditambahkan "+e);;
        }
        
        System.out.println(insert);
        showtables(Fr);
    }

    @Override
    public void showtables(Fr_Inventaris Fr) {
            
         int i=0;

            Object [] rows={"Jenis","Nama Barang","Jumlah","Lokasi","Ruang","Keterangan","Kondisi","Vendor"};
            DefaultTableModel dtm=new DefaultTableModel(null,rows){
               public boolean isCellEditable(int rowIndex, int colIndex) {
                return false;  
            }
            };
          
           
            Fr.TbBarang.setModel(dtm);
            Fr.TbBarang.setBorder(null);
            Fr.TbBarang.removeAll();
//            jScrollPane1.setVisible(true);
//            jScrollPane1.setViewportView(Fr.TbBarang);
             String query="select id_barang,nama_ruang,nama_barang,jumlah_barang,nama_jenis,nama_lokasi,nama_vendor,kondisi,permanen from barang,jenis_barang,lokasi,ruang,vendor where barang.id_jenis_barang=jenis_barang.id_jenis && lokasi.id_lokasi in (select id_gedung from ruang where ruang.id_ruang = barang.id_ruang ) && barang.id_vendor=vendor.id_vendor && barang.id_ruang=ruang.id_ruang;";
        
        
        try{
            Statement stat = Connect.createStatement();
            ResultSet hasil = stat.executeQuery(query);
            
            while(hasil.next()){
                Object[] obj=new Object[8];
                obj[0]=hasil.getString("nama_jenis");
                obj[1]=hasil.getString("nama_barang");
                obj[2]=hasil.getString("jumlah_barang");
                obj[3]=hasil.getString("nama_lokasi");
                obj[4]=hasil.getString("nama_ruang");
                obj[5]=hasil.getString("permanen");
                obj[6]=hasil.getString("kondisi");
                obj[7]=hasil.getString("nama_vendor");
                int id=hasil.getInt("id_barang");
                  
                System.out.println(obj[5]);
                System.out.println(obj[5].toString());
                
               if(Integer.valueOf(obj[5].toString())==1){
                   obj[5]="Permanen";
               } 
               else if (Integer.valueOf(obj[5].toString())==0){
                   obj[5]="Tidak Permanen";
               
               }
//                dtm.addRow(obj);
//                map.put(i, id);
                mapInventaris.put(i,id);
                System.out.println(i+"id"+id);
                i++;
                dtm.addRow(obj);
                        
             }
        }
        catch (SQLException e){
            System.out.println("Gagal eksekusi query select");
        }
    }
    
    @Override
    public void showComboTambah(Popup_TambahInventaris combo){
        
        try {
        
        Object[] objLokasi = new Object[5];    
        String queryVendor = "select nama_vendor from vendor;";
        String queryJenis = "select nama_jenis from jenis_barang;";
        String queryLokasi = "select nama_lokasi from lokasi;";
//        String queryRuang = "select nama_ruang from ruang where id_gedung="+objLokasi;

        
        Statement stat = Connect.createStatement();  
        
        ResultSet hasilVendor = stat.executeQuery(queryVendor);
        
        //show combo Vendor
        while(hasilVendor.next()){
            Object[] obj = new Object[5];
            
            obj[0] = hasilVendor.getString("nama_vendor");
            
            combo.CmbVendor.addItem(obj[0]);      
        }
        hasilVendor.close();
        
        //show combo Jenis
        ResultSet hasilJenis = stat.executeQuery(queryJenis);  
        while(hasilJenis.next()){
            Object[] obj = new Object[5];
            
            obj[0] = hasilJenis.getString("nama_jenis");
            
            combo.CmbJenis.addItem(obj[0]);      
        }
        hasilJenis.close();
        
        //show combo Lokasi  
        ResultSet hasilLokasi = stat.executeQuery(queryLokasi);  
        while(hasilLokasi.next()){
//            Object[] obj = new Object[5];
            
            objLokasi[0] = hasilLokasi.getString("nama_lokasi");
            
            combo.CmbLokasi.addItem(objLokasi[0]);      
        }
            hasilLokasi.close(); 
        
//        //show combo Ruang
//        ResultSet hasilRuang = stat.executeQuery(queryRuang);  
//        while(hasilRuang.next()){
//            Object[] obj = new Object[5];
//            
//            obj[0] = hasilRuang.getString("nama_ruang");
//            
//            combo.CmbRuang.addItem(obj[0]);      
//        }
//            hasilRuang.close();
//            stat.close();
        
        //show combo Keterangan
            Object[] Ket =new Object[2];
            Ket[0]="Permanen";
            Ket[1]="Tidak Permanen";
            combo.CmbKet.addItem(Ket[0]);
            combo.CmbKet.addItem(Ket[1]);
        
        //show combo Kondisi
            Object[] Kondisi = new Object[3];
            Kondisi[0]="Baru";
            Kondisi[1]="Rusak";
            Kondisi[2]="Service";
            combo.CmbKondisi.addItem(Kondisi[0]);
            combo.CmbKondisi.addItem(Kondisi[1]);
            combo.CmbKondisi.addItem(Kondisi[2]);
            
         
        } catch (Exception e) {
            System.out.println(e.getMessage());
            
        }
    }


    @Override
    public void showAtributEdit(Popup_Edit Pop,int row) {
            
            String query=" Select jumlah_barang,nama_barang,nama_vendor from barang,vendor where id_barang="+row+" && barang.id_vendor=vendor.id_vendor;";
        
        try{
        
            Statement stat = Connect.createStatement();
            ResultSet hasil = stat.executeQuery(query);
            
                while(hasil.next()){
                    int jum=hasil.getInt("jumlah_barang");
                    String nama=hasil.getString("nama_barang");
                    String vendor=hasil.getString("nama_vendor");
                    
                    
                    Pop.txtJum.setText(String.valueOf(jum));
                    Pop.LblN.setText("harus <="+jum);
                    Pop.lblNama.setText(nama);
                    Pop.lblVendor.setText(vendor);
                }       
        }
        
        catch (SQLException e){
            
        }
    
        
    }

    @Override
    public void showComboEdit(Popup_Edit Pop) {
        
        String queryLokasi="select nama_lokasi from lokasi";
        String queryRuang="select nama_ruang from ruang";
        
        
        try{
            Statement stat=Connect.createStatement();
            ResultSet hasilLokasi=stat.executeQuery(queryLokasi);
            
                Object[] objLokasi=new Object[1];
            
            while(hasilLokasi.next()){
                
                objLokasi[0]=hasilLokasi.getString("nama_lokasi");
                
                Pop.CmbLokasi.addItem(objLokasi[0]);
            }
            hasilLokasi.close();
//            queryRuang="select nama_ruang from ruang where id_gedung = id_lokasi";
            ResultSet hasilRuang=stat.executeQuery(queryRuang);
            
            while(hasilRuang.next()){
                Object[] objRuang=new Object[1];
                
                objRuang[0]=hasilRuang.getString("nama_ruang");
                
                Pop.CmbRuang.addItem(objRuang[0]);
            }
            hasilRuang.close();
            
            Object[] Kondisi = new Object[3];
            Kondisi[0]="Baru";
            Kondisi[1]="Rusak";
            Kondisi[2]="Service";
            Pop.CmbKondisi.addItem(Kondisi[0]);
            Pop.CmbKondisi.addItem(Kondisi[1]);
            Pop.CmbKondisi.addItem(Kondisi[2]);
            
        }
        catch (SQLException e){
            JOptionPane.showMessageDialog(Pop, "Gagal menampilkan Combo box"+e);
                    
        }
    }

    @Override
    public void pindah(Popup_Edit Pop,int row,int JumlahPindah) {
        
          int jumlah_db=0;
          int jenis=0,lokasi=0,permanen=0,vendor=0;
          String[] obj=new String[2];

          System.out.println("map"+mapInventaris.get(row));
          
          System.out.println("mapbaru"+map.get(row));
  ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////          
        try{
            String query1="select * from barang where id_barang="+mapInventaris.get(row)+";";
            Statement stat = Connect.createStatement();
            ResultSet hasil = stat.executeQuery(query1);
            
            while(hasil.next()){
                jumlah_db=hasil.getInt("jumlah_barang");
                obj[0]=hasil.getString("nama_barang");
                lokasi=hasil.getInt("id_ruang"); //int
                permanen=hasil.getInt("permanen");  //int
                obj[1]=hasil.getString("kondisi");   //varchar
                vendor=hasil.getInt("id_vendor"); //int
                jenis=hasil.getInt("id_jenis_barang"); //int  
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(Pop, "Gagal memindahkan barang "+e);
        }
            
           String ikon = String.valueOf(Pop.CmbKondisi.getSelectedItem());
           int ilok = Pop.CmbRuang.getSelectedIndex()+1;
           
           System.out.println("String ="+ikon+"int :"+ilok);
           
          
           System.out.println(JumlahPindah);
           System.out.println(jumlah_db);
           if(JumlahPindah>jumlah_db){
               JOptionPane.showMessageDialog(Pop, "Gagal, Jumlah barang yang ingin dipindah tidak boleh melebihi barang yang ada saat ini");
           } 
           else if(JumlahPindah<0){
               JOptionPane.showMessageDialog(Pop, "Gagal, Jumlah barang tidak boleh bernilai minus dan nol");
           }
           else if ( lokasi == ilok && obj[1]==ikon){
               //diisi logic
               JOptionPane.showMessageDialog(Pop, "Data tidak pindah kemanapun");
           } else {
               int jumlahTujuan = 0;
                try{
                    //cek semua
                    String sel = "select id_barang, jumlah_barang from barang where nama_barang = '"
                            +obj[0]+"', kondisi = '"
                            +ikon+"', id_ruang = "
                            +ilok+";";
                    //cek kondisi
                    Statement stat = Connect.createStatement();
                    ResultSet hasil = stat.executeQuery(sel);
                    while (hasil.next()){
                        jumlahTujuan = hasil.getInt("jumlah_barang");
                    }
                if (hasil ==null){
                    String insert="INSERT INTO barang (nama_barang,id_ruang,jumlah_barang,id_jenis_barang,kondisi,permanen,id_vendor,flag) VALUES ('"
                        +obj[0]+"',"
                        +lokasi+","
                        +JumlahPindah+","
                        +jenis+",'"
                        +ikon+"',"
                        +permanen+","
                        +vendor+","
                        +1+");";
                    String update = "update barang set jumlah_barang = "+(jumlah_db-JumlahPindah)+"where id_barang = "+mapInventaris.get(row)+";";
                    stat.executeUpdate(insert);
                    stat.executeUpdate(update);
            } else {
                String insert = "update barang set jumlah_barang = "+(jumlahTujuan+JumlahPindah)+"where id_barang = "+mapInventaris.get(row)+";";
                String update = "update barang set jumlah_barang = "+(jumlah_db-JumlahPindah)+"where id_barang = "+mapInventaris.get(row)+";";
                stat.executeUpdate(insert);
                stat.executeUpdate(update);
            }
           } catch (SQLException e){
                JOptionPane.showMessageDialog(Pop, "Gagal memindahkan barang "+e);
           }
           
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////            
        } 
//    showtables(Fr);
    }

    @Override
    public void showComboTambahRuang(Popup_TambahInventaris Pop, Fr_Inventaris Fr,int id){ 
        
        String queryRuang = "select nama_ruang from ruang where id_gedung="+id;	


//show combo ruang
        try {
            Statement stat = Connect.createStatement();
            ResultSet hasilRuang = stat.executeQuery(queryRuang);
        
        while(hasilRuang.next()){
            Object[] obj = new Object[5];
            
            obj[0] = hasilRuang.getString("nama_ruang");
            
            Pop.CmbRuang.addItem(obj[0]);
            
        }
        }catch (SQLException ex) {
            Logger.getLogger(model_inventaris.class.getName()).log(Level.SEVERE, null, ex);
        }
        
            
//            Pop.CmbRuang.addItem(obj[0]);
//            
//        }
//            hasilRuang.close();
//            stat.close();


    }

    @Override
    public void showComboEditRuang(Popup_Edit Pop, Fr_Inventaris Fr, int id) {
        String queryRuang = "select nama_ruang from ruang where id_gedung="+id;	


//show combo ruang
        try {
            Statement stat = Connect.createStatement();
            ResultSet hasilRuang = stat.executeQuery(queryRuang);
        
        while(hasilRuang.next()){
            Object[] obj = new Object[5];
            
            obj[0] = hasilRuang.getString("nama_ruang");
            
            Pop.CmbRuang.addItem(obj[0]);
            
        }
        }catch (SQLException ex) {
            Logger.getLogger(model_inventaris.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }

    @Override
    public void tambah(Popup_TambahVendor Pop, Fr_Vendor Fr) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void tambah(Popup_TambahPinjam Pop, Fr_Pinjam Fr, UI_Login log) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void tambah(Popup_TambahLokasi Pop, Fr_Lokasi Fr) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void tambah(Popup_TambahPegawai Pop, Fr_Pegawai Fr) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
    
    
