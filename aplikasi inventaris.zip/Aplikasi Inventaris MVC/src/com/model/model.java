/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.model;

import com.view.Fr_Inventaris;
import com.view.Fr_Lokasi;
import com.view.Fr_Pegawai;
import com.view.Fr_Pinjam;
import com.view.Fr_Vendor;
import com.view.Popup_TambahInventaris;
import com.view.Popup_TambahLokasi;
import com.view.Popup_TambahPegawai;
import com.view.Popup_TambahPinjam;
import com.view.Popup_TambahVendor;
import com.view.UI_Login;

/**
 *
 * @author USER
 */
public abstract class model {
    
     public abstract void tambah (Popup_TambahVendor Pop,Fr_Vendor Fr);
     
    public abstract void tambah (Popup_TambahInventaris Pop,Fr_Inventaris Fr);
    
    
    public abstract void tambah (Popup_TambahPinjam Pop,Fr_Pinjam Fr, UI_Login log);
    public abstract void tambah (Popup_TambahLokasi Pop,Fr_Lokasi Fr);
    
     public abstract void tambah (Popup_TambahPegawai Pop,Fr_Pegawai Fr);
}
