/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.model;
import com.controller.controller_lokasi;
import java.util.HashMap;
import com.controller.controller_pegawai;
import com.koneksi.koneksi;
import com.view.Fr_Inventaris;
import com.view.Fr_Lokasi;
import com.view.Fr_Pegawai;
import com.view.Fr_Pinjam;
import com.view.Fr_Vendor;
import com.view.Popup_Edit;
import com.view.Popup_TambahInventaris;
import com.view.Popup_TambahLokasi;
import com.view.Popup_TambahPegawai;
import com.view.Popup_TambahPinjam;
import com.view.Popup_TambahVendor;
import com.view.UI_Login;
import java.awt.Component;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;


/**
 *
 * @author USER
 */
public class model_lokasi extends model implements controller_lokasi{
    Connection Connect = koneksi.getKoneksi();
    
     HashMap<Integer, Object> mapLokasi=new HashMap<>();
    
    @Override
    public void tambah(Popup_TambahLokasi Pop, Fr_Lokasi Fr) {
        String namaLokasi=Pop.txtNamaLokasi.getText().trim();
        String namaRuang=Pop.txtNamaRuang.getText().trim();
        int id_gedung=0;
        
        //harus ditambahkan cara mencegah data kosong dan sejenisnya tanya asprak
        
//        string insert = "INSERT INTO lokasi (nama_lokasi,flag) VALUES ('"
//                +namaLokasi+"',"
//                +1+");";
        
        //tambahkan pengecekan seluruh database
//        String cek = "select id_lokasi from lokasi where nama_lokasi = "+namaLokasi+";";
        
       
        
        //select
         String select = "SELECT id_lokasi FROM lokasi where nama_lokasi='"+namaLokasi+"';";
        ResultSet hasil = null;
       
        try{
            Statement stat = Connect.createStatement();
            hasil = stat.executeQuery(select);
            
            while(hasil.next()){                
                id_gedung=hasil.getInt("id_lokasi");                     
            }
        }
        catch (SQLException e){
            System.out.println("Gagal eksekusi query select");
        }
         //insert lokasi
        String insert1 = "INSERT INTO lokasi (nama_lokasi,flag) VALUES ('"
                +namaLokasi+"',"
                +1+");";
        
        //insert ruang
        String insert2 = "INSERT INTO ruang (nama_ruang,id_gedung,flag) VALUES ('"
                +namaRuang+"',"
                +id_gedung+","+1+");"; 
        try{
            if (hasil == null){
                PreparedStatement stat = (PreparedStatement) Connect.prepareStatement(insert1);
                stat.executeUpdate();                
            }
            PreparedStatement stat = (PreparedStatement) Connect.prepareStatement(insert2);
            stat.executeUpdate();
            JOptionPane.showMessageDialog(null,"Data Berhasil ditambahkan ");
            showtables(Fr);
    
        }
        catch (SQLException e){
            JOptionPane.showMessageDialog(null,"Data Gagal ditambahkan "+e);
        }        
        
            System.out.println(insert1);
            System.out.println(insert2);
    }

            
    
    @Override
    public void showtables(Fr_Lokasi Fr) {
            
         int i=0;
            Object [] rows={"Nama Lokasi","Nama Ruang"};
            DefaultTableModel dtm=new DefaultTableModel(null,rows){
              public boolean isCellEditable(int rowIndex, int colIndex) {
                return false;
            }  
            };
            
            
            
            Fr.TbLokasi.setModel(dtm);
            Fr.TbLokasi.setBorder(null);
            Fr.TbLokasi.removeAll();
             String query="select * from ruang,lokasi where id_lokasi=id_gedung;";
        
        
        try{
            Statement stat = Connect.createStatement();
            ResultSet hasil = stat.executeQuery(query);
            
            while(hasil.next()){
                Object[] obj=new Object[3];
                obj[0]=hasil.getString("nama_lokasi");
                obj[1]=hasil.getString("nama_ruang");
                int id =hasil.getInt("id_ruang");
                int flag=hasil.getInt("flag"); 
                
                mapLokasi.put(i,id);
                i++; 
                
                
                if(flag!=0){
                dtm.addRow(obj);
                }
             }
        }
        catch (SQLException e){
            System.out.println("Gagal eksekusi query select");
        }
    }
//
//    @Override
//    public void showAtributEdit(Popup_Edit Pop,int row) {
//            
//            String query=" Select jumlah_barang,nama_barang,nama_vendor from barang,vendor where id_barang="+row+" && barang.id_vendor=vendor.id_vendor;";
//        
//        try{
//        
//            Statement stat = Connect.createStatement();
//            ResultSet hasil = stat.executeQuery(query);
//            
//                while(hasil.next()){
//                    int jum=hasil.getInt("jumlah_barang");
//                    String nama=hasil.getString("nama_barang");
//                    String vendor=hasil.getString("nama_vendor");
//                    
//                    
//                    Pop.txtJum.setText(String.valueOf(jum));
//                    Pop.LblN.setText("harus <="+jum);
//                    Pop.lblNama.setText(nama);
//                    Pop.lblVendor.setText(vendor);
//                }       
//        }
//        
//        catch (SQLException e){
//            
//        }
//    
//        
//    }

    @Override
    public void delete(Fr_Lokasi Fr, int row) {
         String update="update ruang set flag=0 where id_ruang="+mapLokasi.get(row)+";";
        System.out.println(update);
        System.out.println("id:"+row);
        
          try{
            PreparedStatement stat=(PreparedStatement) Connect.prepareStatement(update);
            stat.executeUpdate();
            System.out.println("Delete Berhasil");
              showtables(Fr);
        }
        catch (SQLException e){
            System.out.println("Gagal eksekusi query Delete"+e);
        }
    }

    @Override
    public void tambah(Popup_TambahVendor Pop, Fr_Vendor Fr) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void tambah(Popup_TambahInventaris Pop, Fr_Inventaris Fr) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void tambah(Popup_TambahPinjam Pop, Fr_Pinjam Fr, UI_Login log) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void tambah(Popup_TambahPegawai Pop, Fr_Pegawai Fr) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

 
}
