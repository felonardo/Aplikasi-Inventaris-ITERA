/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.controller;

import java.sql.SQLException;
import com.view.Fr_Lokasi;
import com.view.Popup_TambahLokasi;
import com.view.Popup_Edit;

/**
 *
 * @author USER
 */
public interface controller_lokasi {
//    public void tambah (Popup_TambahLokasi Pop,Fr_Lokasi Fr);
//    public void showComboTambah (Popup_TambahLokasi Pop);
    public void showtables (Fr_Lokasi Fr);
//    public void showAtributEdit (Popup_Edit Pop,int row);
    public void delete (Fr_Lokasi Fr,int id);
//    public void pindah (Popup_Edit Pop,int row,int JumlahPindah);
    
//    public void Simpan (FormBarang bg) throws SQLException;
//    public void Ubah (FormBarang bg) throws SQLException;
//    public void Hapus (FormBarang bg) throws SQLException;
//    public void Tampil (FormBarang bg) throws SQLException;
//    public void Bersih (FormBarang bg) throws SQLException;
//    public void KlikTabel (FormBarang bg) throws SQLException;
}
