/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.controller;

import java.sql.SQLException;
import com.view.Fr_Vendor;
import com.view.Popup_TambahVendor;
import com.view.Popup_EditVendor;

/**
 *
 * @author USER
 */
public interface controller_vendor {
//    public void tambah (Popup_TambahVendor Pop,Fr_Vendor Fr);
//    public void showComboTambah (Popup_TambahPegawai Pop);
    public void showtables (Fr_Vendor Fr);
    public void showAtributEdit (Popup_EditVendor Pop,int row);
    public void delete (Fr_Vendor Fr,int row);
    
//    public void Simpan (FormBarang bg) throws SQLException;
//    public void Ubah (FormBarang bg) throws SQLException;
//    public void Hapus (FormBarang bg) throws SQLException;
//    public void Tampil (FormBarang bg) throws SQLException;
//    public void Bersih (FormBarang bg) throws SQLException;
//    public void KlikTabel (FormBarang bg) throws SQLException;
}
