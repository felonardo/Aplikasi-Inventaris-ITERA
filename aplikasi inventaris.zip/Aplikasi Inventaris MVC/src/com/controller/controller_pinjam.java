/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.controller;

import com.model.model_login;
import com.view.Fr_Pinjam;
import com.view.Popup_TambahPinjam;
//import com.view.Popup_EditPinjam;
import com.view.UI_Login;

/**
 *
 * @author USER
 */
public interface controller_pinjam {
//    public void tambah (Popup_TambahPinjam Pop,Fr_Pinjam Fr, UI_Login log);
    public void showComboTambah (Popup_TambahPinjam Pop);
    public void showtables (Fr_Pinjam Fr);
//    public void showAtributEdit (Popup_EditPinjam Pop,int row);
//    public void showComboEdit (Popup_EditPinjam Pop);
    public void kembali(Fr_Pinjam Fr, int row);
    
//    public void Simpan (FormBarang bg) throws SQLException;
//    public void Ubah (FormBarang bg) throws SQLException;
//    public void Hapus (FormBarang bg) throws SQLException;
//    public void Tampil (FormBarang bg) throws SQLException;
//    public void Bersih (FormBarang bg) throws SQLException;
//    public void KlikTabel (FormBarang bg) throws SQLException;
}
