package com.controller;

import com.view.UI_Login;
import java.sql.SQLException;

public interface controller_login {
    public void Login (UI_Login lgn) throws SQLException;
}
